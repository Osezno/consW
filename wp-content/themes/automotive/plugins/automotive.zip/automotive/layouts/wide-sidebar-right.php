<?php get_header(); ?>
	
    <?php listing_template("wide_right"); ?>

<?php get_footer(); ?>