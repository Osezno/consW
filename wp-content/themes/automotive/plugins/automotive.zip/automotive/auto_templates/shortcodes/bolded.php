<?php
//********************************************
//	Automotive Bolded Shortcode
//***********************************************************

echo "<span style='font-weight: 800;'>" . $content . "</span>";