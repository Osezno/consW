<?php
//********************************************
//	Automotive Pricing Option Shortcode
//***********************************************************

echo "<li>";
echo do_shortcode( $content );
echo "</li>";