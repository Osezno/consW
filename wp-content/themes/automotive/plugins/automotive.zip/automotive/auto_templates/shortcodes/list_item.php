<?php
//********************************************
//	Automotive List Item Shortcode
//***********************************************************

echo "<li>" . $the_icon . do_shortcode( $content ) . "</li>";