<?php
//********************************************
//	Automotive Testimonial Quote Shortcode
//***********************************************************

echo testimonial_slider_quote( $name, $content );