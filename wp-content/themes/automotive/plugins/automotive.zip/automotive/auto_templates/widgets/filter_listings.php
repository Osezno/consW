<?php
//********************************************
//	Automotive Filter Listings Widget
//***********************************************************
global $Listing;

unset($instance['title']);

echo $before_widget;
if ( ! empty( $title ) )
	echo $before_title . $title . $after_title;

$dependancies = $Listing->process_dependancies($_GET);

echo "<div class='dropdowns select-form'>";
foreach($instance as $post_meta => $value){
	if(isset($value) && $value == 1){
		$key     = $Listing->get_single_listing_category($post_meta);

		if(isset($key['slug']) && !empty($key['slug'])){
			$current_option = (isset($_GET[$key['slug']]) && !empty($_GET[$key['slug']]) ? $_GET[$key['slug']] : "");

			echo '<div class="my-dropdown ' . sanitize_html_class($key['slug']) . '-dropdown max-dropdown">';
			$Listing->listing_dropdown($key, $prefix_text, "listing_filter sidebar_widget_filter", (isset($dependancies[$key['slug']]) && !empty($dependancies[$key['slug']]) ? $dependancies[$key['slug']] : ""), array("current_option" => $current_option));
			echo '</div>';
		}
	}
}

echo "</div>";
echo "<button class='btn button reset_widget_filter md-button margin-top-10 margin-bottom-none btn-inventory'>" . __("Reset Search Filters", "listings") . "</button>";
echo "<div class='clearfix'></div>";

echo $after_widget;